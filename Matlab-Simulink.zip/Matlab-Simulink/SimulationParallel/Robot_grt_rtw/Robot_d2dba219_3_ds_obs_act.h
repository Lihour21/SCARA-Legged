/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Robot/Solver Configuration'.
 */
/* Robot_d2dba219_3_ds_obs_act.h - header for method Robot_d2dba219_3_ds_obs_act */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef ROBOT_D2DBA219_3_DS_OBS_ACT_H
#define ROBOT_D2DBA219_3_DS_OBS_ACT_H  1

  extern int32_T Robot_d2dba219_3_ds_obs_act(const NeDynamicSystem *sys, const
    NeDynamicSystemInput *in,NeDsMethodOutput *ou );

#endif                               /* #ifndef ROBOT_D2DBA219_3_DS_OBS_ACT_H */

#ifdef __cplusplus

}
#endif
