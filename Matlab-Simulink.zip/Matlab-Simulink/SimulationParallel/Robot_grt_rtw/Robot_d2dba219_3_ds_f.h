/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Robot/Solver Configuration'.
 */
/* Robot_d2dba219_3_ds_f.h - header for method Robot_d2dba219_3_ds_f */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef ROBOT_D2DBA219_3_DS_F_H
#define ROBOT_D2DBA219_3_DS_F_H        1

  extern int32_T Robot_d2dba219_3_ds_f(const NeDynamicSystem *sys, const
    NeDynamicSystemInput *in,NeDsMethodOutput *ou );

#endif                                 /* #ifndef ROBOT_D2DBA219_3_DS_F_H */

#ifdef __cplusplus

}
#endif
