/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Robot/Solver Configuration'.
 */
/* Robot_d2dba219_2_ds.h - header for module Robot_d2dba219_2_ds */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef ROBOT_D2DBA219_2_DS_H
#define ROBOT_D2DBA219_2_DS_H          1

  extern NeDynamicSystem *Robot_d2dba219_2_dae_ds(PmAllocator *allocator );

#endif                                 /* #ifndef ROBOT_D2DBA219_2_DS_H */

#ifdef __cplusplus

}
#endif
